import React, { useState, useEffect, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { useAppSelector } from "./store/hooks/useTypedSelector"
import { AddPhoneAction, DeletePhoneAction, PhoneActions } from "./store/reducer/phoneReducer"

function App() {

  const [name, setName] = useState<string>("")

  // Получаем свойство phones из стэйта phones
  const { phones } = useAppSelector(state => state.phone)

  // Нужен чтобы вызывать нужные case в switch-ах
  const dispatch = useDispatch()


  /* просто наведи курсором мыши на e там где onSubmit и увидишь тип, я его скопировал и вставил*/
  function handleCreate(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if(name.trim() == ""){
      return;
    }
    dispatch<AddPhoneAction>({
      type: PhoneActions.ADD_PHONE,
      payload: { id: Date.now(), name, price: 0 }
    })
    setName("")
  }

  function handleDelete(id: number) {

    dispatch<DeletePhoneAction>({
      type: PhoneActions.DELETE_PHONE,
      payload: id
    })

  }

  return (
    <div className="App">

      <form onSubmit={(e) => handleCreate(e)}>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
        <button type='submit'>Создать новый телефон</button>
      </form>

      <ol>
        {phones.map((phone) => {
          return (
            <li key={phone.id}>
              {phone.name}
              <button onClick={() => handleDelete(phone.id)}>Удалить</button>
            </li>
          )
        })}
      </ol>

    </div>
  );
}

export default App;
