import { Reducer } from "redux"

// Обычно выносят в отдельный файл с интерфейсами
export interface IPhone {
    id: number,
    name: string,
    price: number
}

// Все action-ы из всех редюсеров обычно выносят в отдельный файл с enum StateActions
export enum PhoneActions {
    ADD_PHONE = "ADD_PHONE",
    DELETE_PHONE = "DELETE_PHONE"
}

// Тип стэйта нашего редюсера
export interface PhoneState {
    phones: Array<IPhone>
}


export interface AddPhoneAction {
    type: PhoneActions.ADD_PHONE,
    payload: IPhone
}
export interface DeletePhoneAction {
    type: PhoneActions.DELETE_PHONE,
    payload: number
}
export type PhoneAction = AddPhoneAction | DeletePhoneAction




// Дефолтное состояние
const defaultState: PhoneState = {
    phones: []
}

const PhoneReducer:Reducer<PhoneState, any> = (state = defaultState, action: PhoneAction): /* Возвращаемый тип функции => */ PhoneState => {
    switch (action.type) {
        case PhoneActions.ADD_PHONE:
            return { phones: [...state.phones, action.payload] };
        case PhoneActions.DELETE_PHONE:
            return { phones: [...state.phones.filter((phone) => phone.id != action.payload)] };
        default:
            return state;
    }
}


export default PhoneReducer