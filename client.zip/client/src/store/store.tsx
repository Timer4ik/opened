import { configureStore } from '@reduxjs/toolkit'
import PhoneReducer from "./reducer/phoneReducer"

export const store = configureStore({
  reducer: {
    phone:PhoneReducer
  }
})

// Нужен для создания hooks/useTypedSelector
export type RootState = ReturnType<typeof store.getState>

