import { TypedUseSelectorHook, useSelector } from "react-redux";
import { RootState } from "../store";

// Типизированный useSelector, чтобы были подсказки
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector
